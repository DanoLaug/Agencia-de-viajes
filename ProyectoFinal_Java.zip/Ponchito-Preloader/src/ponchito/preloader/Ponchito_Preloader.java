/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ponchito.preloader;

import javafx.application.Preloader;
import javafx.application.Preloader.ProgressNotification;
import javafx.application.Preloader.StateChangeNotification;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Ponchito_Preloader extends Preloader {
    private Stage stage;
    
    @Override
    public void start(Stage preloader) throws Exception {
        this.stage = preloader;
        Parent root = FXMLLoader.load(getClass().getResource("Preloader.fxml"));
        Scene scene = new Scene(root);
        preloader.setTitle("Ponchit's Travel - Bienvenido");
        preloader.resizableProperty().setValue(Boolean.FALSE);
        preloader.initStyle(StageStyle.UNDECORATED);
        preloader.setScene(scene);
        preloader.show();
    }
    
   @Override
   public void handleStateChangeNotification(StateChangeNotification stateChangeNotification) {
      if (stateChangeNotification.getType() == StateChangeNotification.Type.BEFORE_START) {
         stage.hide();
      }
    } 
    
}
