package ponchito.preloader;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.animation.RotateTransition;

import javafx.fxml.FXML;

import javafx.scene.shape.Circle;

import javafx.util.Duration;

public class PreloaderController implements Initializable {
 @FXML
    private Circle C1,C2;
   
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        rotacion();

      
    }    
    
    public void rotacion() {
        setRotacion(C1,true,360,5);
        setRotacion(C2,true,180,18);
    }
    
    int rotate = 0;
    private void setRotacion(Circle c, boolean reverse , int angle, int duration) {
          RotateTransition rotatetransition = new RotateTransition(Duration.seconds(duration), c);

          rotatetransition.setAutoReverse(reverse);
          rotatetransition.setByAngle(angle);
          rotatetransition.setDelay(Duration.seconds(0));
          rotatetransition.setRate(3);
          rotatetransition.setCycleCount(18);
          rotatetransition.playFromStart();
        }
    
}
