
package libs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

public class Conexion {
    protected Connection Conn = null;
    private static Conexion conectar;
    private static String p_db = "jdbc:mysql://localhost/ponchitodb";

    public Conexion() {
    }
    
    public static Conexion getInstance() {
        if(conectar == null){
            conectar = new Conexion();
        }
        return conectar;
    }    
    
    public Connection Conectar() {
        try{
            Conn = DriverManager.getConnection(p_db,"root","root");
            System.out.println("Conexion Establecida Correctamente..!");

        }
        catch(SQLException ex){
             
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("ERROR!.");
        alert.setHeaderText(null);
        alert.setContentText("Conexión a BD no establecida");
        
        Optional<ButtonType> option = alert.showAndWait();
            
            
            System.out.println("Conexion Fallida..!");
            System.exit(0);
        }
        return Conn;
    }
    
    public void Desconectar() throws Error {
        if(Conn != null){
            try {
                if(!Conn.isClosed()){
                    Conn.close();
                }
            } catch (SQLException ex) {
                System.out.println("Error en la desconexión");
            }
        }
    }    
}
