
package models;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;

public class LugaresAVisitar {
    StringProperty nombre_lugar;
    
    public LugaresAVisitar (String nombre_lugar) {
        this.nombre_lugar = new SimpleStringProperty(nombre_lugar);
    }
    
    public LugaresAVisitar () {}
    
    public StringProperty getNombre_lugar() {
        return nombre_lugar;
    }

    public void setNombre_lugar(StringProperty nombre_lugar) {
        this.nombre_lugar = nombre_lugar;
    }
    
    @Override
    public String toString() {
        return nombre_lugar.get();
    }
    
    public static void llenar_lugar(Connection xp, ObservableList<Ciudades> lista) {
            
        try {
            Statement linea;
            String y = "SELECT nombre_lugar FROM lugaresavisitar;";
            linea = xp.createStatement();
            ResultSet rs = linea.executeQuery(y);
            
            while (rs.next()) {
                lista.add(new Ciudades(
                        rs.getString("nombre_lugar")
                ));
            }

            
        } catch (SQLException ex) {
            System.out.println("Falla en la Conexión a B.D.");
            String xq = "Error en la Conexion: ";
            xq += " SQLState = " + ex.getSQLState();
            xq += " SQLErrorCode = " + ex.getErrorCode();
            xq += " Message = " + ex.getMessage();
            System.out.println(xq);        
        } catch (Error ex) {
                    System.out.println("Falla en la Desconexión");
        }
    }
}
