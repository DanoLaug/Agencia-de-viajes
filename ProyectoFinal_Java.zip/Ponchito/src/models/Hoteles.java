
package models;

public class Hoteles {
    
}
