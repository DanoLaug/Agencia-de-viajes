package models;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;


public class Circuitos {
    StringProperty codigo_circuito;
    
    public Circuitos (String codigo_circuito) {
    this.codigo_circuito = new SimpleStringProperty(codigo_circuito);
    }
    
    public Circuitos () {}
    
    public StringProperty getCodigo_circuito() {
        return codigo_circuito;
    }

    public void setCodigo_circuito(StringProperty codigo_circuito) {
        this.codigo_circuito = codigo_circuito;
    }
    
    @Override
    public String toString() {
        return codigo_circuito.get();
    }
    
    public static void llenar_ciudad(Connection xp, ObservableList<Ciudades> lista) {
            
        try {
            Statement linea;
            String y = "SELECT nombre_ciudad, pais_ciudad FROM ciudades;";
            linea = xp.createStatement();
            ResultSet rs = linea.executeQuery(y);
            
            while (rs.next()) {
                lista.add(new Ciudades(
                    rs.getString("codigo_circuito")
                ));
            }

            
        } catch (SQLException ex) {
            System.out.println("Falla en la Conexión a B.D.");
            String xq = "Error en la Conexion: ";
            xq += " SQLState = " + ex.getSQLState();
            xq += " SQLErrorCode = " + ex.getErrorCode();
            xq += " Message = " + ex.getMessage();
            System.out.println(xq);        
        } catch (Error ex) {
                    System.out.println("Falla en la Desconexión");
        }
    }
}