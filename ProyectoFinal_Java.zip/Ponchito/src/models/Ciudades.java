
package models;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;

public class Ciudades {
    StringProperty nombre_ciudad;
    
    public Ciudades (String nombre_ciudad) {
    this.nombre_ciudad = new SimpleStringProperty(nombre_ciudad);
    }
    
    public Ciudades () {}
    
    public StringProperty getNombre_ciudad() {
        return nombre_ciudad;
    }

    public void setNombre(StringProperty nombre_ciudad) {
        this.nombre_ciudad = nombre_ciudad;
    }
    
    @Override
    public String toString() {
        return nombre_ciudad.get();
    }
    
    public static void llenar_ciudad(Connection xp, ObservableList<Ciudades> lista) {
            
        try {
            Statement linea;
            String y = "SELECT nombre_ciudad, pais_ciudad FROM ciudades;";
            linea = xp.createStatement();
            ResultSet rs = linea.executeQuery(y);
            
            while (rs.next()) {
                lista.add(new Ciudades(
                    rs.getString("nombre_ciudad")
                ));
            }

            
        } catch (SQLException ex) {
            System.out.println("Falla en la Conexión a B.D.");
            String xq = "Error en la Conexion: ";
            xq += " SQLState = " + ex.getSQLState();
            xq += " SQLErrorCode = " + ex.getErrorCode();
            xq += " Message = " + ex.getMessage();
            System.out.println(xq);        
        } catch (Error ex) {
                    System.out.println("Falla en la Desconexión");
        }
    }
}
