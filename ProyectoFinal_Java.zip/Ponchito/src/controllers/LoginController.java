/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.jfoenix.controls.*;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import libs.Conexion;
import models.Ciudades;

/**
 * FXML Controller class
 *
 * @author danie
 */
public class LoginController implements Initializable {
    
    Integer x = 0;
    private String cadena = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    
    @FXML
    private AnchorPane panel;

    @FXML
    private JFXButton login_btn;
    
    @FXML 
    private JFXButton simular_btn;
    
    @FXML
    private JFXPasswordField psw_txt;
    
    @FXML 
    private JFXTextField usr_txt;
    
    @FXML
    private TextField nombre_txt;
    
    @FXML
    private ComboBox c_lugar;
    
    @FXML
    private ComboBox<Ciudades> c_ciudad;
    ObservableList<Ciudades> lista_ciudades;
    
    @FXML 
    private DatePicker f_salida;
    
    @FXML 
    private DatePicker f_llegada;
    
    @FXML
    private TextField personas_txt;
    
    @FXML
    private Label simulacion_monto;
    
    @FXML
    private Label simulacion_codigo;
    
    
    @FXML
    public void g_codes() {
        int x=5;
        StringBuilder builder = new StringBuilder();
        while (x-- != 0) {
        int character = (int)(Math.random()*cadena.length());
        builder.append(cadena.charAt(character));
        }
        simulacion_codigo.setText(builder.toString());
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cfg();
    }

    public void limpiar() {
        nombre_txt.clear();
        f_salida.setValue(LocalDate.now().minusYears(1));
        f_llegada.setValue(LocalDate.now().minusYears(1));
        simulacion_monto.setText("Monto");
    }
    
    public void cfg() {
        Conexion conectado = new Conexion();
        lista_ciudades = FXCollections.observableArrayList();
        Ciudades.llenar_ciudad(conectado.Conectar(), lista_ciudades);
        c_ciudad.setItems(lista_ciudades);
        
        simular_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                Conexion conectado = new Conexion();        
                Connection xp = conectado.Conectar();
                if(!personas_txt.getText().isEmpty() || !nombre_txt.getText().isEmpty()) {
                    Integer win = 0;
                try {
                    g_codes();
                    simulacion_monto.setText("99.99 $");
                    PreparedStatement linea, l2,l3;
                    
                    String y = "INSERT INTO simulaciones "
                            + "(codigo_simulacion, nombre_persona, "
                            + "fecha_salida, fecha_llegada, costo_simulacion, ciudad_id, circuito_id)"
                            + "VALUES (?, ?, ?, ?, ?, ?, ?); ";


                    
                    linea = xp.prepareStatement(y);
                    linea.setString(1, simulacion_codigo.getText().toUpperCase());
                    linea.setString(2, nombre_txt.getText().toUpperCase());
                    LocalDate salida = f_salida.getValue(); 
                    linea.setDate(3, Date.valueOf(salida));
                    LocalDate llegada = f_llegada.getValue(); 
                    linea.setDate(4, Date.valueOf(llegada)); 
                    linea.setString(5, "99.99");
                    linea.setString(6, "1");
                    linea.setString(7, "1");
                    
                    linea.execute();
                    linea.close();
                    conectado.Desconectar();                     
                    System.out.println("Inserciòn Ok..!");

                    
                    
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("RECHICKEN");
                    alert.setHeaderText("SE HAN GUARDADO CORRECTAMENTE LOS DATOS POR FAVOR"+"\n"+
                            "GUARDE ESTE CODIGO ANTES DE PRESIONAR ACEPTAR");
                    alert.setContentText("CODIGO DE SIMULACIÓN: "+simulacion_codigo.getText().toUpperCase());
                    
                    //por aca anduvo daniel otra vez
                    Optional<ButtonType> option = alert.showAndWait();
                    if (option.get() == ButtonType.OK) {
                        limpiar();
                    }
                    

                    
                } catch (SQLException ex) {
                    
                    System.out.println("Falla en la Conexión a B.D.");
                    String xq = "Error en la Conexion: ";
                    xq += " SQLState = " + ex.getSQLState();
                    xq += " SQLErrorCode = " + ex.getErrorCode();
                    xq += " Message = " + ex.getMessage();
                    System.out.println(xq);          
                    
                } catch (Error ex) {
                    System.out.println("Falla en la Desconexión");
                }
                
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("CAMPOS VACIOS O NO SELECCIONADOS");
                    alert.setHeaderText(null);
                    alert.setContentText("TODOS LOS CAMPOS DEBEN ESTAR LLENOS Y/O SELECCIONADOS");
                    //por aca anduvo daniel otra vez
                    Optional<ButtonType> option = alert.showAndWait();
                }
            }
        }); 
        
        login_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                iniciar();
            }
        });
    }
    
    
     public void iniciar() {

       Conexion conn = new Conexion();        
       Connection xp = conn.Conectar(); 

       try {
        PreparedStatement p;
        String comm_sql = "SELECT * FROM user WHERE username = ? and password = ?;";
        p = xp.prepareStatement(comm_sql);
        p.setString(1, usr_txt.getText()); 
        p.setString(2, psw_txt.getText());
        ResultSet rs = p.executeQuery();
        
            
        
        if (!rs.next()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("THIS IS A GRABEICHON MESACH");
            alert.setHeaderText(null);
            alert.setContentText("USUARIO O CONTRASEÑA INCORRECTOS");
            Optional<ButtonType> option = alert.showAndWait();

            System.out.println("esos no son los datos");
            x+=1;
            System.out.println("va, "+x.toString()+" intento erroneo.");
            usr_txt.clear();
            psw_txt.clear();

             if(x >=3) {     
            Alert psw_e = new Alert(Alert.AlertType.ERROR);
            psw_e.setTitle("ERROR!!!!");
            psw_e.setHeaderText(null);
            psw_e.setContentText("DEMASIADOS INTENTOS ERRONEOS, GRACIAS, VUELVA PRONTO :* !");
            Optional<ButtonType> option2 = psw_e.showAndWait();
            if (option.get() == ButtonType.OK) {
                System.exit(0);
            }
           
       }
           
       } else {
            System.out.println("a mira si era tu clave xd");
            login();
            p.close();
            conn.Desconectar();
        }
        
        
        } catch (SQLException ex) {
            
            System.out.println("Falla en la Conexión a B.D.");
            String xq = "Error en la Conexion: ";
            xq += " SQLState = " + ex.getSQLState();
            xq += " SQLErrorCode = " + ex.getErrorCode();
            xq += " Message = " + ex.getMessage();
            System.out.println(xq);
            
        } catch (Error ex) {
            System.out.println("Falla en la Desconexión");
        }
       
       
       
       
   }
            public void login() {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/Main.fxml"));  

                try {


                     System.out.println("Funciona? el try?");

                     Parent root = (Parent) loader.load();
                     Stage principal = new Stage();
                     principal.setScene(new Scene(root));
                     principal.setResizable(false);
                     principal.centerOnScreen();
                     principal.resizableProperty().setValue(Boolean.FALSE); //evita que se agrande la ventana
                     principal.setTitle("Menu Principal - Ponchito");
                     principal.show();

                     Stage cerrarLogin = (Stage) panel.getScene().getWindow();
                     cerrarLogin.hide();

                 } catch(IOException ex) {
                    Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
                 }
        
        System.out.println("hola");
    }
    

    
    
}
