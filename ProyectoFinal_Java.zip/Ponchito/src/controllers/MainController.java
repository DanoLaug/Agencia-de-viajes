/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author danie
 */
public class MainController implements Initializable {
    
    @FXML
    private AnchorPane anchorpane;

    @FXML
    private void wip() {
        Alert psw_e = new Alert(Alert.AlertType.WARNING);
        psw_e.setTitle("Sorry!!!!");
        psw_e.setHeaderText(null);
        psw_e.setContentText("Work in Progress");
        Optional<ButtonType> option = psw_e.showAndWait();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    
    @FXML
    private void Logout(ActionEvent event) {
        anchorpane.setEffect(new GaussianBlur());
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("ATENCIÓN!");
        alert.setHeaderText(null);
        alert.setContentText("¿Desea Cambiar de Usuario?");
        
        Optional<ButtonType> option = alert.showAndWait();
        
        if (option.get() == ButtonType.OK) {
                    anchorpane.setEffect(null);
            try {
                Stage viewLogin = (Stage) anchorpane.getScene().getWindow();
                viewLogin.close();
                
                Parent root = FXMLLoader.load(getClass().getResource("/views/Login.fxml"));
                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.setTitle("Ponchito's Tavel - LOGIN");
                stage.centerOnScreen();
                stage.resizableProperty().setValue(Boolean.FALSE);
                stage.setResizable(false);
                stage.setScene(scene);   
                stage.show();
            } catch (IOException ex) {
                Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (option.get() == ButtonType.CANCEL) {
            anchorpane.setEffect(null); 
        }
    }    
}
