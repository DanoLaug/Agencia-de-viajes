package ponchito;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import libs.Conexion;


public class Ponchito extends Application {
   Conexion Conectar = new Conexion();
    
    @Override
    public void init() throws Exception {
        Thread.sleep(1500);
    } 
    
    static Stage stg;
    @Override
    public void start(Stage stage) throws Exception {
        Ponchito.stg = stage; 
        Parent root = FXMLLoader.load(getClass().getResource("/views/Login.fxml"));
       try {
           root = FXMLLoader.load(getClass().getResource("/views/Login.fxml"));
       } catch (IOException ex) {
           System.out.println("ERROR AL INICIARLIZAR!");
       }

        stage.setTitle("Ponchito's Tavel - LOGIN");
        stage.resizableProperty().setValue(Boolean.FALSE);
        stage.setScene(new Scene (root));
        stage.setResizable(false);
        stage.centerOnScreen();
        stage.show();  
    }
}